package nombres;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/* Análisis: 
 * Pregunta: ¿Tiene pares clave/valor o solo valores? --> Valores
 * Pregunta: ¿Contiene duplicados? --> No
 * Pregunta: ¿Su tarea principal es buscar elementos? --> No
 * Respuesta: ArrayList */
public class Principal {

	public static void main(String[] args) {

		/* Fields */
		/**
		 * Arraylist donde se guardan los nombres
		 */
		ArrayList<String> nombres = new ArrayList<>();
		
		/**
		 * Atributo donde iremos almacenando nombres
		 */
		String nombre;
		
		/* Apertura de Scanner */
		Scanner scannercito = new Scanner(System.in);
		
		/* Inserción de nombres */
		System.out.println("Introduzca 5 nombres.");
		for(int i = 0; i < 5; i++) {
			
			System.out.print("Nombre " + (i+1) + ": ");
			nombre = scannercito.nextLine();
			
			//Adding with the .add(thing) method
			nombres.add(nombre);
			
		}//Fin FOR --> adding names
		
		System.out.println("Showing names added: ");
		
		//Showing names
		Collections.sort(nombres, Collections.reverseOrder());
		System.out.println(nombres);
		
		/* Cierre de Scanner */
		scannercito.close();
		
		
	}

}
