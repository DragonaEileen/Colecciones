package televisiones;

import java.util.HashMap;
import java.util.Scanner;

/* Análisis: 
 * Pregunta: ¿Tiene pares clave/valor o solo valores? --> Pares
 * Pregunta: ¿El orden es importante? --> No
 * Respuesta: HashMap */
public class Principal {
	
	/**
	 * Mapa global, para no tener que ir pasandolo cada vez a  las funciones
	 */
	static HashMap<String, Double> series = new HashMap<>(); // No es necesario definir el contenido a la derecha, ya esta en la izquierda

	public static void main(String[] args) {

		/* Fields */
		/**
		 * Atributo para almacenar el nombre de la serie
		 */
		String serie;
		
		/**
		 * Atributo para almacenar la valoración de la serie
		 */
		Double rating;
		
		/**
		 * Atributo para almacenar la selección del usuario
		 */
		int option = 1;
		
		/* Apertura de Scanner */
		Scanner scannercito = new Scanner(System.in);
		
		/* Menu: loop until exit is pressed */
		System.out.println("Welcome to TV Show Rating!!");
		do{
			
			System.out.println("1.- Add Show. \n"
					+ "2.- Search Show. \n"
					+ "3.- Remove Show. \n"
					+ "0.- Exit.");
			System.out.print("Your choice: ");
			option = scannercito.nextInt();
			
			//Cleaning
			scannercito.nextLine();
			
			switch (option) {
			case 1:
				
				System.out.println("Adding Show!!");
				System.out.print("Name of the Show? --> ");
				serie = scannercito.nextLine();
				
				System.out.print("Rating of the Show? --> ");
				rating = scannercito.nextDouble();
				
				addSeries(serie, rating);
				System.out.println("Show Added!!");
				
				//Reset
				serie = "";
				rating = 0.0;
				
				break;
				
			case 2:
				
				System.out.println("Searching Show!!");
				System.out.print("Name of the Show? --> ");
				serie = scannercito.nextLine();
				
				rating = searchSeries(serie);
				
				System.out.print("Your Show's rating is: " + rating + "\n");
				
				//Reset
				serie = "";
				rating = 0.0;
				
				break;
				
			case 3:
				
				System.out.println("Removing Show!!");
				System.out.print("Name of the Show? --> ");
				serie = scannercito.nextLine();
				
				removeSeries(serie);
				
				System.out.println("Show Removed!!");
				
				//Reset
				serie = "";
				
				break;
				
			default:
					
					System.err.println("Oh-oh, something's wrong.");
				
				break;
				
			};
			
		}while(option != 0);
		
		/* Cierre de Scanner */
		scannercito.close();
		
	}
	
	/**
	 * Método para agregar serie
	 * 
	 * @param serie Nombre de la serie
	 * @param rating Valoración de la serie
	 */
	public static void addSeries(String serie, Double rating) {
		
		//We add it with the .put() method
		series.put(serie, rating);
		
	}//Fin addSeries()
	
	/**
	 * Método para buscar serie, que devuelve una valoración
	 * 
	 * @param serie Nombre de la serie
	 * @return rating Valoración de la serie
	 */
	public static Double searchSeries(String serie) {
		
		//We return the value with .get(Key)
		return series.get(serie);
		
	}//Fin seqarchSeries()
	
	/**
	 * Método para eliminar una serie
	 * 
	 * @param serie Nombre d ela serie a eliminar
	 */
	public static void removeSeries(String serie) {
		
		//We remove the serie with the method .remove(Key)
		series.remove(serie);
		
	}//Fin removeSeries()
	
}
